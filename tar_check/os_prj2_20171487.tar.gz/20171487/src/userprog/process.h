#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"

tid_t process_execute (const char *file_name);
int process_wait (tid_t);
void process_exit (void);
void process_activate (void);

size_t parse_filename(char *origin, char *argv[32]);
void construct_stack(size_t argc, char *argv[32], void **esp);

#endif /* userprog/process.h */

